import json
import pandas as pd
from datetime import datetime
import re

def load_config():
    with open('config.json') as f:
        return json.load(f)

def extract_skills(description):
    common_skills = [
        'python', 'java', 'sql', 'aws', 'docker', 'kubernetes',
        'machine learning', 'data analysis', 'javascript', 'react',
        'node.js', 'flask', 'django', 'git', 'azure', 'google cloud',
        'tensorflow', 'pytorch', 'pandas', 'numpy', 'tableau', 'power bi',
        'spark', 'hadoop', 'linux', 'html', 'css', 'typescript', 'angular',
        'vue', 'mongodb', 'postgresql', 'mysql', 'nosql', 'ci/cd', 'jenkins',
        'agile', 'scrum', 'rest api', 'graphql', 'microservices'
    ]
    return [skill.title() for skill in common_skills if skill in description.lower()] or ['Not Specified']

def save_to_csv(data, filename='job_listings.csv'):
    df = pd.DataFrame(data)
    df.to_csv(filename, index=False)
    return filename

def analyze_trends(data):
    if not data:
        return {}
    
    df = pd.DataFrame(data)
    
    return {
        'top_titles': df['title'].value_counts().head(5).to_dict(),
        'top_skills': pd.Series([skill for sublist in df['skills'] for skill in sublist]).value_counts().head(10).to_dict(),
        'top_locations': df['location'].value_counts().head(5).to_dict(),
        'posting_trends': df['date_posted'].value_counts().sort_index().to_dict() if 'date_posted' in df.columns else {}
    }
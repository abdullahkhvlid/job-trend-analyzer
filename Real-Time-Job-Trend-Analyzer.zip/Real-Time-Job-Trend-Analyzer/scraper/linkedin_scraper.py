from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from .utils import load_config, extract_skills
import time
from urllib.parse import quote

def scrape_linkedin(keyword="", location=""):
    config = load_config()
    
    options = Options()
    options.add_argument(f"user-agent={config['scraping']['user_agent']}")
    if config['scraping']['headless']:
        options.add_argument("--headless=new")
    
    try:
        service = Service(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service, options=options)
        driver.implicitly_wait(config['scraping']['delay'])
        
        keyword = quote(keyword) if keyword else "software"
        location = quote(location) if location else ""
        url = f"{config['linkedin']['base_url']}{config['linkedin']['search_path'].format(keyword=keyword, location=location)}"
        driver.get(url)
        time.sleep(3)
        
        jobs = []
        job_cards = WebDriverWait(driver, 15).until(
            EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'div.base-card'))
        )[:config['scraping']['max_listings']]

        for card in job_cards:
            try:
                title = card.find_element(By.CSS_SELECTOR, 'h3.base-search-card__title').text
                company = card.find_element(By.CSS_SELECTOR, 'h4.base-search-card__subtitle').text
                location = card.find_element(By.CSS_SELECTOR, 'span.job-search-card__location').text
                date_posted = card.find_element(By.CSS_SELECTOR, 'time.job-search-card__listdate').text
                job_url = card.find_element(By.CSS_SELECTOR, 'a.base-card__full-link').get_attribute('href')
                
                # Open new tab for description
                driver.execute_script("window.open('');")
                driver.switch_to.window(driver.window_handles[1])
                driver.get(job_url)
                time.sleep(2)
                
                desc = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, 'div.description__text'))
                ).text
                
                jobs.append({
                    'title': title,
                    'company': company,
                    'location': location,
                    'date_posted': date_posted,
                    'skills': extract_skills(desc),
                    'source': 'LinkedIn',
                    'description': desc[:200] + "...",
                    'url': job_url
                })
                
                # Close tab and switch back
                driver.close()
                driver.switch_to.window(driver.window_handles[0])
                time.sleep(1)
                
            except Exception as e:
                if len(driver.window_handles) > 1:
                    driver.close()
                    driver.switch_to.window(driver.window_handles[0])
                continue
                
        return jobs
        
    except Exception as e:
        print(f"LinkedIn scraping failed: {str(e)}")
        return []
    finally:
        if 'driver' in locals():
            driver.quit()
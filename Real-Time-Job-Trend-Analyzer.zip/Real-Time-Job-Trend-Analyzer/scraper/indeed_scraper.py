from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from .utils import load_config, extract_skills
import time
from urllib.parse import quote

def scrape_indeed(keyword="", location=""):
    config = load_config()
    
    options = Options()
    options.add_argument(f"user-agent={config['scraping']['user_agent']}")
    if config['scraping']['headless']:
        options.add_argument("--headless=new")
    
    try:
        service = Service(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service, options=options)
        driver.implicitly_wait(config['scraping']['delay'])
        
        keyword = quote(keyword) if keyword else "software"
        location = quote(location) if location else ""
        url = f"{config['indeed']['base_url']}{config['indeed']['search_path'].format(keyword=keyword, location=location)}"
        driver.get(url)
        
        jobs = []
        job_cards = WebDriverWait(driver, 15).until(
            EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'div.job_seen_beacon'))
        )[:config['scraping']['max_listings']]

        for card in job_cards:
            try:
                card.click()
                time.sleep(1)
                
                title = card.find_element(By.CSS_SELECTOR, 'h2.jobTitle').text
                company = card.find_element(By.CSS_SELECTOR, 'span.companyName').text
                location = card.find_element(By.CSS_SELECTOR, 'div.companyLocation').text
                date_posted = card.find_element(By.CSS_SELECTOR, 'span.date').text
                job_url = driver.current_url
                
                desc = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.ID, 'jobDescriptionText'))
                ).text
                
                jobs.append({
                    'title': title,
                    'company': company,
                    'location': location,
                    'date_posted': date_posted,
                    'skills': extract_skills(desc),
                    'source': 'Indeed',
                    'description': desc[:200] + "...",
                    'url': job_url
                })
                
            except Exception as e:
                continue
                
        return jobs
        
    except Exception as e:
        print(f"Indeed scraping failed: {str(e)}")
        return []
    finally:
        if 'driver' in locals():
            driver.quit()
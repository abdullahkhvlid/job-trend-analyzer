import streamlit as st
from scraper.indeed_scraper import scrape_indeed
from scraper.linkedin_scraper import scrape_linkedin
from scraper.utils import analyze_trends, save_to_csv
import pandas as pd
import plotly.express as px
from datetime import datetime

# App config
st.set_page_config(page_title="Job Trend Analyzer", layout="wide")

# UI Components
st.title("🔍 Real-Time Job Trend Analyzer")
st.markdown("Analyze job market trends from Indeed and LinkedIn")

with st.sidebar:
    st.header("Search Parameters")
    keyword = st.text_input("Job Title", "Data Analyst")
    location = st.text_input("Location", "")
    platforms = st.multiselect("Platforms", ["Indeed", "LinkedIn"], default=["Indeed", "LinkedIn"])
    max_results = st.slider("Max Results", 10, 100, 50)
    run_scraper = st.button("Fetch Jobs")

# Session state
if 'jobs' not in st.session_state:
    st.session_state.jobs = []
if 'last_fetch' not in st.session_state:
    st.session_state.last_fetch = None

# Main logic
if run_scraper:
    with st.spinner("Fetching jobs..."):
        all_jobs = []
        if "Indeed" in platforms:
            all_jobs.extend(scrape_indeed(keyword, location)[:max_results])
        if "LinkedIn" in platforms:
            all_jobs.extend(scrape_linkedin(keyword, location)[:max_results])
        
        st.session_state.jobs = all_jobs
        st.session_state.last_fetch = datetime.now()
        st.success(f"Fetched {len(all_jobs)} jobs!")

# Display results
if st.session_state.jobs:
    st.markdown("---")
    st.header("Job Market Trends")
    
    # Download button
    csv_file = save_to_csv(st.session_state.jobs)
    with open(csv_file, "rb") as f:
        st.download_button("Download CSV", f, "job_listings.csv")
    
    # Analytics
    trends = analyze_trends(st.session_state.jobs)
    
    col1, col2 = st.columns(2)
    with col1:
        st.subheader("Top Job Titles")
        st.dataframe(pd.DataFrame(trends['top_titles'].items(), columns=["Title", "Count"]))
        fig = px.bar(trends['top_titles'], title="Top 5 Job Titles")
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.subheader("Top Locations")
        st.dataframe(pd.DataFrame(trends['top_locations'].items(), columns=["Location", "Count"]))
        fig = px.pie(trends['top_locations'], names="Location", values="Count", title="Hiring Locations")
        st.plotly_chart(fig, use_container_width=True)
    
    st.subheader("Top Skills")
    st.dataframe(pd.DataFrame(trends['top_skills'].items(), columns=["Skill", "Count"]))
    fig = px.bar(trends['top_skills'], title="Top 10 Skills")
    st.plotly_chart(fig, use_container_width=True)
    
    if trends['posting_trends']:
        st.subheader("Posting Trends")
        trends_df = pd.DataFrame(trends['posting_trends'].items(), columns=["Date", "Count"])
        fig = px.line(trends_df, x="Date", y="Count", title="Job Postings Over Time")
        st.plotly_chart(fig, use_container_width=True)
    
    st.subheader("Sample Jobs")
    st.dataframe(pd.DataFrame(st.session_state.jobs).head(10))
else:
    st.info("Enter search parameters and click 'Fetch Jobs'")